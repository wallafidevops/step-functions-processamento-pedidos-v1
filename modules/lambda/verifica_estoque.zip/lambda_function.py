
def lambda_handler(event, context):
    tem_estoque = True
    for item in event.get("itens", []):
        if item.get("quantidade", 0) > 10:
            tem_estoque = False
    
    return { "tem_estoque": tem_estoque }
