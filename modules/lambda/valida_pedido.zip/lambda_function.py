
def lambda_handler(event, context):
    if "cliente" not in event or "itens" not in event:
        raise Exception("Pedido inválido")
    
    return {
        "pedido_valido": True,
        "cliente": event["cliente"],
        "itens": event["itens"]
    }
